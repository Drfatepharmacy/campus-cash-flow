-- UniEgo production hardening: financial integrity, idempotency, atomic settlement,
-- webhook replay protection, association tenancy, and privileged-account isolation.
-- Existing `admin` remains the platform-level Super Admin role for backward compatibility.

-- ---------------------------------------------------------------------------
-- Financial integrity / payment idempotency
-- ---------------------------------------------------------------------------
ALTER TABLE public.transactions
  ADD COLUMN IF NOT EXISTS idempotency_key text,
  ADD COLUMN IF NOT EXISTS currency text NOT NULL DEFAULT 'NGN',
  ADD COLUMN IF NOT EXISTS gateway_amount_kobo bigint,
  ADD COLUMN IF NOT EXISTS gateway_currency text,
  ADD COLUMN IF NOT EXISTS authorization_url text,
  ADD COLUMN IF NOT EXISTS access_code text,
  ADD COLUMN IF NOT EXISTS initialization_token uuid,
  ADD COLUMN IF NOT EXISTS initialization_claimed_at timestamptz;

CREATE UNIQUE INDEX IF NOT EXISTS idx_txn_student_request_idempotency
  ON public.transactions(student_id, payment_request_id, idempotency_key)
  WHERE idempotency_key IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_txn_reference ON public.transactions(reference);
CREATE INDEX IF NOT EXISTS idx_txn_request ON public.transactions(payment_request_id);

DO $$ BEGIN
  ALTER TABLE public.transactions
    ADD CONSTRAINT txn_amount_integrity_chk
    CHECK (
      base_amount >= 0
      AND service_charge >= 0
      AND total_amount = base_amount + service_charge
    ) NOT VALID;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE public.transactions
    ADD CONSTRAINT txn_currency_chk CHECK (currency = 'NGN') NOT VALID;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- Enforce the financial transaction state machine even for privileged code.
CREATE OR REPLACE FUNCTION public.enforce_transaction_state_transition()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF NEW.status = OLD.status THEN RETURN NEW; END IF;
  IF OLD.status = 'pending' AND NEW.status IN ('paid','failed') THEN RETURN NEW; END IF;
  IF OLD.status = 'paid' AND NEW.status = 'refunded' THEN RETURN NEW; END IF;
  RAISE EXCEPTION 'INVALID_TRANSACTION_STATE_TRANSITION: % -> %', OLD.status, NEW.status;
END;
$$;
DROP TRIGGER IF EXISTS enforce_transaction_state_transition ON public.transactions;
CREATE TRIGGER enforce_transaction_state_transition
BEFORE UPDATE OF status ON public.transactions
FOR EACH ROW EXECUTE FUNCTION public.enforce_transaction_state_transition();

-- Browser clients must never create or mutate authoritative financial records.
REVOKE INSERT, UPDATE, DELETE ON public.transactions FROM authenticated;
DROP POLICY IF EXISTS "txn_self_insert" ON public.transactions;
DROP POLICY IF EXISTS "txn_admin_update" ON public.transactions;

-- ---------------------------------------------------------------------------
-- Webhook replay / processing ledger
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.webhook_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider text NOT NULL,
  event_key text NOT NULL,
  event_type text NOT NULL,
  reference text,
  status text NOT NULL DEFAULT 'received' CHECK (status IN ('received','processed','rejected','failed')),
  payload jsonb,
  error_code text,
  received_at timestamptz NOT NULL DEFAULT now(),
  processed_at timestamptz,
  UNIQUE(provider, event_key)
);
ALTER TABLE public.webhook_events ENABLE ROW LEVEL SECURITY;
GRANT ALL ON public.webhook_events TO service_role;
REVOKE ALL ON public.webhook_events FROM anon, authenticated;
CREATE INDEX IF NOT EXISTS idx_webhook_reference ON public.webhook_events(reference);
CREATE INDEX IF NOT EXISTS idx_webhook_received_at ON public.webhook_events(received_at DESC);

-- ---------------------------------------------------------------------------
-- Distributed abuse protection for sensitive server operations
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.rate_limit_windows (
  bucket text NOT NULL,
  subject text NOT NULL,
  window_start timestamptz NOT NULL,
  hits integer NOT NULL DEFAULT 0 CHECK (hits >= 0),
  PRIMARY KEY (bucket, subject, window_start)
);
ALTER TABLE public.rate_limit_windows ENABLE ROW LEVEL SECURITY;
GRANT ALL ON public.rate_limit_windows TO service_role;
REVOKE ALL ON public.rate_limit_windows FROM anon, authenticated;
CREATE INDEX IF NOT EXISTS idx_rate_limit_window_start ON public.rate_limit_windows(window_start);

CREATE OR REPLACE FUNCTION public.consume_rate_limit(
  p_bucket text,
  p_subject text,
  p_limit integer,
  p_window_seconds integer
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_window timestamptz;
  v_hits integer;
BEGIN
  IF p_limit < 1 OR p_window_seconds < 1 OR length(p_bucket) > 100 OR length(p_subject) > 200 THEN
    RAISE EXCEPTION 'INVALID_RATE_LIMIT';
  END IF;
  v_window := to_timestamp(floor(extract(epoch FROM clock_timestamp()) / p_window_seconds) * p_window_seconds);
  INSERT INTO public.rate_limit_windows(bucket, subject, window_start, hits)
  VALUES (p_bucket, p_subject, v_window, 1)
  ON CONFLICT (bucket, subject, window_start)
  DO UPDATE SET hits = public.rate_limit_windows.hits + 1
  RETURNING hits INTO v_hits;
  RETURN v_hits <= p_limit;
END;
$$;
REVOKE ALL ON FUNCTION public.consume_rate_limit(text,text,integer,integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.consume_rate_limit(text,text,integer,integer) TO service_role;

-- ---------------------------------------------------------------------------
-- Association tenancy / leadership roles
-- ---------------------------------------------------------------------------
DO $$ BEGIN
  CREATE TYPE public.association_status AS ENUM ('pending','active','suspended','rejected');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TYPE public.association_role AS ENUM ('president','treasurer','financial_secretary','staff_adviser','member');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

CREATE TABLE IF NOT EXISTS public.associations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campus_id uuid REFERENCES public.campuses(id) ON DELETE SET NULL,
  name text NOT NULL,
  slug text NOT NULL UNIQUE,
  status public.association_status NOT NULL DEFAULT 'pending',
  created_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE RESTRICT,
  approved_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  approved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.associations ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.associations TO authenticated;
GRANT ALL ON public.associations TO service_role;
DROP TRIGGER IF EXISTS associations_updated ON public.associations;
CREATE TRIGGER associations_updated BEFORE UPDATE ON public.associations
FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

CREATE TABLE IF NOT EXISTS public.association_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  association_id uuid NOT NULL REFERENCES public.associations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.association_role NOT NULL DEFAULT 'member',
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','revoked')),
  assigned_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  assigned_at timestamptz NOT NULL DEFAULT now(),
  revoked_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  revoked_at timestamptz,
  UNIQUE(association_id, user_id, role)
);
ALTER TABLE public.association_members ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.association_members TO authenticated;
GRANT ALL ON public.association_members TO service_role;
CREATE INDEX IF NOT EXISTS idx_assoc_members_user ON public.association_members(user_id, association_id);
CREATE INDEX IF NOT EXISTS idx_assoc_members_assoc_role ON public.association_members(association_id, role, status);

CREATE TABLE IF NOT EXISTS public.association_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  association_id uuid NOT NULL UNIQUE REFERENCES public.associations(id) ON DELETE CASCADE,
  bank_name text,
  account_name text,
  account_number text,
  currency text NOT NULL DEFAULT 'NGN' CHECK (currency = 'NGN'),
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.association_accounts ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.association_accounts TO authenticated;
GRANT ALL ON public.association_accounts TO service_role;
DROP TRIGGER IF EXISTS association_accounts_updated ON public.association_accounts;
CREATE TRIGGER association_accounts_updated BEFORE UPDATE ON public.association_accounts
FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

ALTER TABLE public.payment_requests ADD COLUMN IF NOT EXISTS association_id uuid REFERENCES public.associations(id) ON DELETE SET NULL;
ALTER TABLE public.settlements ADD COLUMN IF NOT EXISTS association_id uuid REFERENCES public.associations(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_payment_requests_association ON public.payment_requests(association_id);
CREATE INDEX IF NOT EXISTS idx_settlements_association ON public.settlements(association_id);

CREATE TABLE IF NOT EXISTS public.settlement_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  settlement_id uuid NOT NULL REFERENCES public.settlements(id) ON DELETE CASCADE,
  transaction_id uuid NOT NULL UNIQUE REFERENCES public.transactions(id) ON DELETE RESTRICT,
  base_amount numeric(12,2) NOT NULL,
  service_charge numeric(12,2) NOT NULL,
  total_amount numeric(12,2) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(settlement_id, transaction_id)
);
ALTER TABLE public.settlement_items ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.settlement_items TO authenticated;
GRANT ALL ON public.settlement_items TO service_role;
CREATE INDEX IF NOT EXISTS idx_settlement_items_settlement ON public.settlement_items(settlement_id);

-- ---------------------------------------------------------------------------
-- Authorization helpers
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.is_platform_admin(_user_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT public.has_role(_user_id, 'admin'::public.app_role)
$$;
REVOKE ALL ON FUNCTION public.is_platform_admin(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_platform_admin(uuid) TO authenticated, service_role;

CREATE OR REPLACE FUNCTION public.has_association_role(
  _user_id uuid,
  _association_id uuid,
  _role public.association_role
)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.association_members am
    WHERE am.user_id = _user_id
      AND am.association_id = _association_id
      AND am.role = _role
      AND am.status = 'active'
  )
$$;
REVOKE ALL ON FUNCTION public.has_association_role(uuid, uuid, public.association_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_association_role(uuid, uuid, public.association_role) TO authenticated, service_role;

CREATE OR REPLACE FUNCTION public.is_association_member(_user_id uuid, _association_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.association_members am
    WHERE am.user_id = _user_id
      AND am.association_id = _association_id
      AND am.status = 'active'
  )
$$;
REVOKE ALL ON FUNCTION public.is_association_member(uuid, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_association_member(uuid, uuid) TO authenticated, service_role;

CREATE OR REPLACE FUNCTION public.can_view_association_account(_user_id uuid, _association_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT public.is_platform_admin(_user_id)
    OR EXISTS (
      SELECT 1 FROM public.association_members am
      WHERE am.user_id = _user_id
        AND am.association_id = _association_id
        AND am.status = 'active'
        AND am.role IN ('president','treasurer','financial_secretary','staff_adviser')
    )
$$;
REVOKE ALL ON FUNCTION public.can_view_association_account(uuid, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.can_view_association_account(uuid, uuid) TO authenticated, service_role;

-- ---------------------------------------------------------------------------
-- Association RLS
-- ---------------------------------------------------------------------------
DROP POLICY IF EXISTS assoc_read ON public.associations;
CREATE POLICY assoc_read ON public.associations FOR SELECT TO authenticated USING (
  status = 'active'
  OR created_by = auth.uid()
  OR public.is_platform_admin(auth.uid())
  OR public.is_association_member(auth.uid(), associations.id)
);

DROP POLICY IF EXISTS assoc_members_read ON public.association_members;
CREATE POLICY assoc_members_read ON public.association_members FOR SELECT TO authenticated USING (
  user_id = auth.uid()
  OR public.is_platform_admin(auth.uid())
  OR public.is_association_member(auth.uid(), association_members.association_id)
);

DROP POLICY IF EXISTS assoc_accounts_read ON public.association_accounts;
CREATE POLICY assoc_accounts_read ON public.association_accounts FOR SELECT TO authenticated USING (
  public.can_view_association_account(auth.uid(), association_id)
);

DROP POLICY IF EXISTS settlement_items_admin_read ON public.settlement_items;
CREATE POLICY settlement_items_admin_read ON public.settlement_items FOR SELECT TO authenticated USING (
  public.is_platform_admin(auth.uid())
  OR EXISTS (
    SELECT 1 FROM public.settlements s
    WHERE s.id = settlement_items.settlement_id
      AND s.association_id IS NOT NULL
      AND public.can_view_association_account(auth.uid(), s.association_id)
  )
);

-- No client-side mutation of association authority/account records.
REVOKE INSERT, UPDATE, DELETE ON public.associations FROM authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.association_members FROM authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.association_accounts FROM authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.settlement_items FROM authenticated;

-- Platform role changes are now server-authoritative so the last-Super-Admin guard
-- and audit trail cannot be bypassed through the REST API.
REVOKE INSERT, UPDATE, DELETE ON public.user_roles FROM authenticated;
DROP POLICY IF EXISTS "roles_admin_write" ON public.user_roles;
DROP POLICY IF EXISTS "roles_admin_delete" ON public.user_roles;

-- Settlements are now mutated through trusted atomic RPCs only.
REVOKE INSERT, UPDATE, DELETE ON public.settlements FROM authenticated;
DROP POLICY IF EXISTS "settlements_admin_all" ON public.settlements;
CREATE POLICY settlements_admin_read ON public.settlements FOR SELECT TO authenticated USING (
  public.is_platform_admin(auth.uid())
  OR (association_id IS NOT NULL AND public.can_view_association_account(auth.uid(), association_id))
);

-- ---------------------------------------------------------------------------
-- Canonical payment finalization RPC
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.finalize_payment(
  p_reference text,
  p_gateway_id text,
  p_paid_at timestamptz,
  p_gateway_amount_kobo bigint,
  p_gateway_currency text,
  p_gateway_payload jsonb,
  p_actor_id uuid DEFAULT NULL,
  p_source text DEFAULT 'verification'
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_txn public.transactions%ROWTYPE;
  v_expected_kobo bigint;
  v_receipt public.receipts%ROWTYPE;
  v_new boolean := false;
BEGIN
  SELECT * INTO v_txn
  FROM public.transactions
  WHERE reference = p_reference
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('status','not_found');
  END IF;

  IF v_txn.status = 'paid' THEN
    SELECT * INTO v_receipt FROM public.receipts WHERE transaction_id = v_txn.id;
    RETURN jsonb_build_object(
      'status','paid',
      'newly_finalized',false,
      'transaction_id',v_txn.id,
      'receipt_token',v_receipt.qr_token
    );
  END IF;

  IF v_txn.status IN ('refunded','failed') THEN
    RETURN jsonb_build_object('status','invalid_state','current_state',v_txn.status);
  END IF;

  v_expected_kobo := round(v_txn.total_amount * 100)::bigint;

  IF p_gateway_amount_kobo IS NULL OR p_gateway_amount_kobo <> v_expected_kobo THEN
    INSERT INTO public.audit_logs(actor_id, action, entity, entity_id, metadata)
    VALUES (
      p_actor_id,
      'payment.amount_mismatch',
      'transaction',
      v_txn.id::text,
      jsonb_build_object(
        'reference', p_reference,
        'expected_kobo', v_expected_kobo,
        'gateway_kobo', p_gateway_amount_kobo,
        'source', p_source
      )
    );
    RETURN jsonb_build_object('status','amount_mismatch','expected_kobo',v_expected_kobo);
  END IF;

  IF upper(coalesce(p_gateway_currency,'')) <> upper(v_txn.currency) THEN
    INSERT INTO public.audit_logs(actor_id, action, entity, entity_id, metadata)
    VALUES (
      p_actor_id,
      'payment.currency_mismatch',
      'transaction',
      v_txn.id::text,
      jsonb_build_object(
        'reference', p_reference,
        'expected_currency', v_txn.currency,
        'gateway_currency', p_gateway_currency,
        'source', p_source
      )
    );
    RETURN jsonb_build_object('status','currency_mismatch','expected_currency',v_txn.currency);
  END IF;

  UPDATE public.transactions
  SET status = 'paid',
      paid_at = coalesce(p_paid_at, now()),
      paystack_ref = p_gateway_id,
      paystack_response = p_gateway_payload,
      gateway_amount_kobo = p_gateway_amount_kobo,
      gateway_currency = upper(p_gateway_currency)
  WHERE id = v_txn.id;

  INSERT INTO public.receipts(transaction_id, qr_token)
  VALUES (v_txn.id, 'UEG-' || upper(replace(gen_random_uuid()::text, '-', '')))
  ON CONFLICT (transaction_id) DO NOTHING;

  SELECT * INTO v_receipt FROM public.receipts WHERE transaction_id = v_txn.id;
  v_new := true;

  INSERT INTO public.audit_logs(actor_id, action, entity, entity_id, metadata)
  VALUES (
    p_actor_id,
    'payment.completed',
    'transaction',
    v_txn.id::text,
    jsonb_build_object(
      'reference', p_reference,
      'total_amount', v_txn.total_amount,
      'gateway_id', p_gateway_id,
      'source', p_source
    )
  );

  RETURN jsonb_build_object(
    'status','paid',
    'newly_finalized',v_new,
    'transaction_id',v_txn.id,
    'receipt_token',v_receipt.qr_token
  );
END;
$$;
REVOKE ALL ON FUNCTION public.finalize_payment(text,text,timestamptz,bigint,text,jsonb,uuid,text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.finalize_payment(text,text,timestamptz,bigint,text,jsonb,uuid,text) TO service_role;

-- ---------------------------------------------------------------------------
-- Atomic settlement batching with row locking and immutable item snapshots
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.create_settlement_atomic(
  p_actor_id uuid,
  p_notes text DEFAULT NULL,
  p_department_id uuid DEFAULT NULL,
  p_association_id uuid DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_ids uuid[];
  v_amount numeric(12,2);
  v_settlement public.settlements%ROWTYPE;
  v_reference text;
  v_count integer;
  v_updated integer;
BEGIN
  IF NOT public.is_platform_admin(p_actor_id) THEN
    RAISE EXCEPTION 'FORBIDDEN';
  END IF;

  SELECT ARRAY(
    SELECT t.id
    FROM public.transactions t
    JOIN public.payment_requests pr ON pr.id = t.payment_request_id
    WHERE t.status = 'paid'
      AND t.settlement_id IS NULL
      AND (p_department_id IS NULL OR pr.target_department_id = p_department_id)
      AND (p_association_id IS NULL OR pr.association_id = p_association_id)
    ORDER BY t.created_at, t.id
    FOR UPDATE OF t SKIP LOCKED
  ) INTO v_ids;

  v_count := coalesce(cardinality(v_ids), 0);
  IF v_count = 0 THEN
    RAISE EXCEPTION 'NO_UNSETTLED_TRANSACTIONS';
  END IF;

  SELECT coalesce(sum(base_amount),0) INTO v_amount
  FROM public.transactions WHERE id = ANY(v_ids);

  v_reference := 'SETL-' || upper(substr(replace(gen_random_uuid()::text,'-',''), 1, 20));

  INSERT INTO public.settlements(reference, amount, notes, department_id, association_id)
  VALUES (v_reference, v_amount, p_notes, p_department_id, p_association_id)
  RETURNING * INTO v_settlement;

  INSERT INTO public.settlement_items(settlement_id, transaction_id, base_amount, service_charge, total_amount)
  SELECT v_settlement.id, t.id, t.base_amount, t.service_charge, t.total_amount
  FROM public.transactions t
  WHERE t.id = ANY(v_ids);

  UPDATE public.transactions
  SET settlement_id = v_settlement.id
  WHERE id = ANY(v_ids) AND settlement_id IS NULL;

  GET DIAGNOSTICS v_updated = ROW_COUNT;
  IF v_updated <> v_count THEN
    RAISE EXCEPTION 'SETTLEMENT_CONFLICT';
  END IF;

  INSERT INTO public.audit_logs(actor_id, action, entity, entity_id, metadata)
  VALUES (
    p_actor_id,
    'settlement.created',
    'settlement',
    v_settlement.id::text,
    jsonb_build_object('reference',v_reference,'count',v_count,'amount',v_amount,'department_id',p_department_id,'association_id',p_association_id)
  );

  RETURN jsonb_build_object(
    'ok',true,
    'id',v_settlement.id,
    'reference',v_reference,
    'count',v_count,
    'amount',v_amount
  );
END;
$$;
REVOKE ALL ON FUNCTION public.create_settlement_atomic(uuid,text,uuid,uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.create_settlement_atomic(uuid,text,uuid,uuid) TO service_role;

CREATE OR REPLACE FUNCTION public.complete_settlement_atomic(
  p_actor_id uuid,
  p_settlement_id uuid,
  p_bank_reference text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_settlement public.settlements%ROWTYPE;
BEGIN
  IF NOT public.is_platform_admin(p_actor_id) THEN
    RAISE EXCEPTION 'FORBIDDEN';
  END IF;

  SELECT * INTO v_settlement FROM public.settlements WHERE id = p_settlement_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'SETTLEMENT_NOT_FOUND'; END IF;

  IF v_settlement.status IN ('deposited','confirmed') THEN
    RETURN jsonb_build_object('ok',true,'status',v_settlement.status,'idempotent',true);
  END IF;

  IF v_settlement.status = 'flagged' THEN
    RAISE EXCEPTION 'INVALID_SETTLEMENT_STATE';
  END IF;

  UPDATE public.settlements
  SET status = 'deposited', settled_at = now(), bank_reference = p_bank_reference
  WHERE id = p_settlement_id;

  INSERT INTO public.audit_logs(actor_id, action, entity, entity_id, metadata)
  VALUES (p_actor_id, 'settlement.deposited', 'settlement', p_settlement_id::text, jsonb_build_object('bank_reference',p_bank_reference));

  RETURN jsonb_build_object('ok',true,'status','deposited','idempotent',false);
END;
$$;
REVOKE ALL ON FUNCTION public.complete_settlement_atomic(uuid,uuid,text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.complete_settlement_atomic(uuid,uuid,text) TO service_role;

-- ---------------------------------------------------------------------------
-- Association management RPCs. All authority changes are platform-admin only.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.create_association_application(
  p_actor_id uuid,
  p_name text,
  p_slug text,
  p_campus_id uuid DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_assoc public.associations%ROWTYPE;
BEGIN
  IF p_actor_id IS NULL THEN RAISE EXCEPTION 'UNAUTHORIZED'; END IF;
  IF length(trim(p_name)) < 2 THEN RAISE EXCEPTION 'INVALID_ASSOCIATION_NAME'; END IF;
  IF p_slug !~ '^[a-z0-9]+(?:-[a-z0-9]+)*$' THEN RAISE EXCEPTION 'INVALID_ASSOCIATION_SLUG'; END IF;

  INSERT INTO public.associations(name, slug, campus_id, created_by)
  VALUES (trim(p_name), lower(trim(p_slug)), p_campus_id, p_actor_id)
  RETURNING * INTO v_assoc;

  INSERT INTO public.association_members(association_id, user_id, role, status, assigned_by)
  VALUES (v_assoc.id, p_actor_id, 'member', 'active', p_actor_id)
  ON CONFLICT (association_id, user_id, role) DO NOTHING;

  INSERT INTO public.audit_logs(actor_id, action, entity, entity_id, metadata)
  VALUES (p_actor_id, 'association.application_created', 'association', v_assoc.id::text, jsonb_build_object('name',v_assoc.name,'slug',v_assoc.slug));

  RETURN jsonb_build_object('ok',true,'id',v_assoc.id,'status',v_assoc.status);
END;
$$;
REVOKE ALL ON FUNCTION public.create_association_application(uuid,text,text,uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.create_association_application(uuid,text,text,uuid) TO service_role;

CREATE OR REPLACE FUNCTION public.approve_association(
  p_actor_id uuid,
  p_association_id uuid,
  p_approve boolean
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_platform_admin(p_actor_id) THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;

  UPDATE public.associations
  SET status = CASE WHEN p_approve THEN 'active'::public.association_status ELSE 'rejected'::public.association_status END,
      approved_by = p_actor_id,
      approved_at = CASE WHEN p_approve THEN now() ELSE NULL END
  WHERE id = p_association_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'ASSOCIATION_NOT_FOUND'; END IF;

  INSERT INTO public.audit_logs(actor_id, action, entity, entity_id, metadata)
  VALUES (p_actor_id, CASE WHEN p_approve THEN 'association.approved' ELSE 'association.rejected' END, 'association', p_association_id::text, '{}'::jsonb);

  RETURN jsonb_build_object('ok',true);
END;
$$;
REVOKE ALL ON FUNCTION public.approve_association(uuid,uuid,boolean) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.approve_association(uuid,uuid,boolean) TO service_role;

CREATE OR REPLACE FUNCTION public.set_association_role(
  p_actor_id uuid,
  p_association_id uuid,
  p_user_id uuid,
  p_role public.association_role,
  p_grant boolean
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_platform_admin(p_actor_id) THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;

  IF p_grant THEN
    INSERT INTO public.association_members(association_id,user_id,role,status,assigned_by,assigned_at,revoked_by,revoked_at)
    VALUES (p_association_id,p_user_id,p_role,'active',p_actor_id,now(),NULL,NULL)
    ON CONFLICT (association_id,user_id,role)
    DO UPDATE SET status='active', assigned_by=excluded.assigned_by, assigned_at=now(), revoked_by=NULL, revoked_at=NULL;
  ELSE
    UPDATE public.association_members
    SET status='revoked', revoked_by=p_actor_id, revoked_at=now()
    WHERE association_id=p_association_id AND user_id=p_user_id AND role=p_role;
  END IF;

  INSERT INTO public.audit_logs(actor_id, action, entity, entity_id, metadata)
  VALUES (
    p_actor_id,
    CASE WHEN p_grant THEN 'association.role_granted' ELSE 'association.role_revoked' END,
    'association',
    p_association_id::text,
    jsonb_build_object('user_id',p_user_id,'role',p_role)
  );

  RETURN jsonb_build_object('ok',true);
END;
$$;
REVOKE ALL ON FUNCTION public.set_association_role(uuid,uuid,uuid,public.association_role,boolean) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.set_association_role(uuid,uuid,uuid,public.association_role,boolean) TO service_role;

CREATE OR REPLACE FUNCTION public.upsert_association_account(
  p_actor_id uuid,
  p_association_id uuid,
  p_bank_name text,
  p_account_name text,
  p_account_number text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT (
    public.is_platform_admin(p_actor_id)
    OR public.has_association_role(p_actor_id,p_association_id,'president')
    OR public.has_association_role(p_actor_id,p_association_id,'treasurer')
  ) THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;

  INSERT INTO public.association_accounts(association_id,bank_name,account_name,account_number,updated_by)
  VALUES (p_association_id,trim(p_bank_name),trim(p_account_name),trim(p_account_number),p_actor_id)
  ON CONFLICT (association_id) DO UPDATE
    SET bank_name=excluded.bank_name,
        account_name=excluded.account_name,
        account_number=excluded.account_number,
        updated_by=p_actor_id,
        updated_at=now();

  INSERT INTO public.audit_logs(actor_id, action, entity, entity_id, metadata)
  VALUES (p_actor_id,'association.account_updated','association',p_association_id::text,jsonb_build_object('bank_name',trim(p_bank_name)));

  RETURN jsonb_build_object('ok',true);
END;
$$;
REVOKE ALL ON FUNCTION public.upsert_association_account(uuid,uuid,text,text,text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.upsert_association_account(uuid,uuid,text,text,text) TO service_role;

-- Audit query performance
CREATE INDEX IF NOT EXISTS idx_audit_created_at ON public.audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_receipts_qr_token ON public.receipts(qr_token);
