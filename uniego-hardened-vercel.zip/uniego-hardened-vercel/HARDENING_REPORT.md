# UniEgo backend hardening report

## Scope

The supplied TanStack Start/React frontend design and route pattern were retained. Changes focus on Supabase/PostgreSQL, server functions, Paystack, authentication recovery, association tenancy, security headers, and Vercel deployment.

## Critical issues addressed

1. **Client-created financial records** — authenticated browser access to insert/update/delete transactions is revoked.
2. **Client-controlled payment authority** — amount, charge, reference and callback URL are generated/validated server-side.
3. **Floating-point payment boundary** — authoritative gateway calculations use integer kobo; PostgreSQL retains `NUMERIC(12,2)` and amount integrity constraints.
4. **Payment races** — transaction idempotency keys plus an initialization claim prevent concurrent gateway initialization for the same transaction.
5. **Payment finalization races** — webhook and manual verification converge on `finalize_payment`, which row-locks the transaction and creates at most one receipt.
6. **Gateway mismatch** — Paystack reference, status, amount and currency are validated before the internal payment is finalized.
7. **Webhook replay** — signed webhook events are persisted in an idempotency ledger and duplicate processed deliveries are acknowledged safely.
8. **Predictable receipt/QR tokens** — receipt tokens use UUID-derived cryptographic randomness; general generated QR tokens now do the same.
9. **Settlement double-batching** — `create_settlement_atomic` locks eligible transaction rows with `FOR UPDATE ... SKIP LOCKED`, snapshots settlement membership, verifies row count, and prevents a transaction belonging to multiple settlements.
10. **Unsafe first-admin claim** — the public claim mechanism was removed. Existing `admin` is treated as platform Super Admin and first bootstrap is manual/trusted.
11. **Role bypass** — direct authenticated writes to `user_roles` are revoked; platform role changes pass through server-side Super Admin checks and audit logging.
12. **Association tenancy** — new association, membership, scoped role and account structures have RLS and server-authoritative mutations.
13. **RLS recursion risk** — association membership checks use security-definer helper predicates instead of recursively querying the protected policy table.
14. **Password recovery** — Supabase reset flow was added using the existing UniEgo auth visual language and generic non-enumerating responses.
15. **Public receipt privacy** — public verification masks matric number and limits the payer name.
16. **Abuse protection** — sensitive payment verification/initialization and association creation use a database-backed rate-limit window.
17. **Vercel readiness** — Vercel framework metadata, Nitro-on-Vercel wrapper configuration, server environment contract and security headers were added.

## Principal files changed/added

- `src/lib/payments.functions.ts`
- `src/lib/payment-security.ts`
- `src/lib/payment-security.test.ts`
- `src/routes/api/public/webhooks/paystack.ts`
- `src/lib/settlements.functions.ts`
- `src/lib/admin.functions.ts`
- `src/lib/authz.ts`
- `src/lib/associations.functions.ts`
- `src/lib/verify.functions.ts`
- `src/lib/qr-encoder.ts`
- `src/lib/qr-encoder.test.ts`
- `src/routes/auth.tsx`
- `src/routes/_authenticated/dashboard.tsx`
- `src/routes/_authenticated/admin/users.tsx`
- `src/routes/_authenticated/pay.$requestId.tsx`
- `src/server.ts`
- `vite.config.ts`
- `vercel.json`
- `.env.example`
- `.gitignore`
- `package.json`
- `supabase/migrations/20260802130000_uniego_production_hardening.sql`
- `SECURITY_DEPLOYMENT.md`
- `HARDENING_REPORT.md`

## Association role model

Platform authority remains the existing `admin` role, displayed as **Super Admin**. It is independent of association tenancy.

Association-scoped roles:
- President
- Treasurer
- Financial Secretary
- Staff Adviser
- Member

Super Admin approves associations and grants/revokes scoped roles. President/Treasurer may modify settlement account information. President/Treasurer/Financial Secretary/Staff Adviser may view authorized association account information. These roles do not grant platform-wide administration.

## Database migration

The new migration is additive and does not edit prior migration files. It adds financial integrity columns/constraints/indexes, webhook replay storage, rate limits, association tenancy tables/RLS, immutable settlement item snapshots, transaction-state enforcement, atomic payment finalization, atomic settlement RPCs, and association-management RPCs.

## Vercel behavior

The existing Lovable TanStack configuration wrapper is retained rather than duplicated. Nitro is enabled by the wrapper when `process.env.VERCEL` is present. `vercel.json` explicitly sets the TanStack Start framework preset. Server secrets remain standard server environment variables and are never `VITE_*` values.

## Validation status

Source-level hardening and static checks are included. A full dependency install/build cannot be completed in the execution environment if `@lovable.dev/vite-tanstack-config@2.7.7` is unavailable through its configured package registry. Run the following in a normal networked project environment before production deployment:

```bash
npm ci
npm run typecheck
npm run lint
npm test
npm run build
```

Do not deploy if any of those commands fail.

## External configuration still required

- Apply the Supabase migration to staging/production.
- Configure server-only Supabase service-role credentials.
- Configure Paystack test/live keys and webhook URL.
- Configure Supabase Auth site/redirect URLs and Google OAuth if used.
- Configure `APP_URL` to the production HTTPS domain.
- Configure receipt-email integrations only if that feature is enabled.
- Manually provision the first Super Admin for a fresh database.
