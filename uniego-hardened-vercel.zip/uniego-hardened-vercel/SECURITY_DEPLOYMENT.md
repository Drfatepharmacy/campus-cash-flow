# UniEgo secure deployment

## 1. Apply database migrations

Apply all existing Supabase migrations in order, including:

`supabase/migrations/20260802130000_uniego_production_hardening.sql`

Use a staging Supabase project first and take a database backup before applying production migrations.

## 2. Bootstrap the first Super Admin

The public "first user claims admin" flow has been removed. Existing `admin` rows are retained and treated as the platform-level **Super Admin** role for compatibility.

For a brand-new database, provision the initial Super Admin manually from a trusted Supabase SQL session after that user has signed up:

```sql
insert into public.user_roles (user_id, role)
values ('<AUTH_USER_UUID>', 'admin'::public.app_role)
on conflict (user_id, role) do nothing;
```

Do not expose this operation through a public route or client UI.

## 3. Vercel environment variables

Configure these in Vercel Project Settings. Never prefix secrets with `VITE_`.

Public/browser-safe:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_PUBLISHABLE_KEY`
- `VITE_SUPABASE_PROJECT_ID`

Server-only:
- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `PAYSTACK_SECRET_KEY`
- `APP_URL` (canonical HTTPS production origin)
- `RESEND_API_KEY` if receipt email is enabled
- `LOVABLE_API_KEY` if the Lovable connector gateway is used for receipt email

Production Paystack secrets should only exist in the Production Vercel environment unless Preview is deliberately connected to Paystack test mode.

## 4. Supabase Auth configuration

In Supabase Auth URL configuration, add the production site URL and approved redirect URLs. Password recovery returns to `/auth?mode=reset` on the same trusted application origin.

Configure Google OAuth redirect URLs separately if Google sign-in is enabled.

## 5. Paystack webhook

Point the Paystack webhook to:

`https://<production-domain>/api/public/webhooks/paystack`

The endpoint validates the Paystack SHA-512 HMAC signature, records replay state, validates reference/amount/currency, and calls the same atomic payment finalizer used by manual verification.

## 6. Vercel

`vercel.json` identifies the framework as `tanstack-start`. `vite.config.ts` enables the Lovable wrapper's Nitro build only when `VERCEL` is present, retaining the existing Lovable/local preview behavior while allowing Nitro to emit Vercel Functions.

Use Node.js 22 on Vercel. No SPA fallback rewrite is required or desired for TanStack Start SSR.

## 7. Production verification checklist

- Sign up and sign in.
- Request a password reset and complete the recovery flow.
- Confirm a student cannot directly insert/update `transactions` through Supabase.
- Confirm a non-Super-Admin cannot mutate `user_roles`.
- Submit an association application.
- Approve it as Super Admin and assign President/Treasurer/Financial Secretary/Staff Adviser.
- Confirm those roles cannot access platform Super Admin routes.
- Confirm President/Treasurer can update the association settlement account.
- Confirm President/Treasurer/Financial Secretary/Staff Adviser can view authorized account information.
- Initialize a Paystack **test-mode** payment and confirm the amount is server-calculated.
- Replay the same webhook and verify it is processed idempotently.
- Send a validly signed test event with an incorrect amount and verify the payment remains unfinalized.
- Trigger manual verification and webhook delivery concurrently and confirm one receipt exists.
- Trigger two settlement creations concurrently and confirm no transaction is included twice.
- Refresh nested Vercel routes directly and confirm they do not return Vercel's default 404.
