import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listUsersWithRoles, setUserRole } from "@/lib/settlements.functions";
import { approveAssociation, listAssociationMembersAdmin, listAssociationsAdmin, setAssociationRole } from "@/lib/associations.functions";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Check, X } from "lucide-react";
import { useMemo, useState } from "react";

export const Route = createFileRoute("/_authenticated/admin/users")({
  head: () => ({ meta: [{ title: "Users & roles — Admin" }] }),
  component: UsersPage,
});

type Role = "admin" | "student" | "faculty_rep" | "department_rep" | "bank_runner";

const ROLES: { value: Role; label: string; tone: string }[] = [
  { value: "admin", label: "Super Admin", tone: "bg-royal text-royal-foreground" },
  { value: "faculty_rep", label: "Faculty rep", tone: "bg-gold text-gold-foreground" },
  { value: "department_rep", label: "Dept rep", tone: "bg-emerald text-emerald-foreground" },
  { value: "bank_runner", label: "Bank runner", tone: "bg-foreground text-background" },
  { value: "student", label: "Student", tone: "" },
];


type AssociationRole = "president" | "treasurer" | "financial_secretary" | "staff_adviser" | "member";
const ASSOCIATION_ROLES: { value: AssociationRole; label: string }[] = [
  { value: "president", label: "President" },
  { value: "treasurer", label: "Treasurer" },
  { value: "financial_secretary", label: "Fin. Secretary" },
  { value: "staff_adviser", label: "Staff Adviser" },
  { value: "member", label: "Member" },
];

function UsersPage() {
  const qc = useQueryClient();
  const listFn = useServerFn(listUsersWithRoles);
  const setFn = useServerFn(setUserRole);
  const listAssociationsFn = useServerFn(listAssociationsAdmin);
  const approveAssociationFn = useServerFn(approveAssociation);
  const listAssociationMembersFn = useServerFn(listAssociationMembersAdmin);
  const setAssociationRoleFn = useServerFn(setAssociationRole);
  const q = useQuery({ queryKey: ["admin-users"], queryFn: () => listFn() });
  const associations = useQuery({ queryKey: ["admin-associations"], queryFn: () => listAssociationsFn() });
  const [search, setSearch] = useState("");
  const [associationId, setAssociationId] = useState("");
  const associationMembers = useQuery({
    queryKey: ["admin-association-members", associationId],
    queryFn: () => listAssociationMembersFn({ data: { association_id: associationId } }),
    enabled: Boolean(associationId),
  });

  const mut = useMutation({
    mutationFn: (vars: { user_id: string; role: Role; grant: boolean }) => setFn({ data: vars }),
    onSuccess: (_d, v) => { toast.success(`${v.grant ? "Granted" : "Revoked"} ${v.role.replace("_", " ")}`); qc.invalidateQueries({ queryKey: ["admin-users"] }); },
    onError: (e: Error) => toast.error(e.message),
  });


  const associationApproval = useMutation({
    mutationFn: (vars: { association_id: string; approve: boolean }) => approveAssociationFn({ data: vars }),
    onSuccess: (_d, vars) => {
      toast.success(vars.approve ? "Association approved" : "Association rejected");
      qc.invalidateQueries({ queryKey: ["admin-associations"] });
      qc.invalidateQueries({ queryKey: ["admin-association-members"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const associationRoleMutation = useMutation({
    mutationFn: (vars: { association_id: string; user_id: string; role: AssociationRole; grant: boolean }) => setAssociationRoleFn({ data: vars }),
    onSuccess: (_d, vars) => {
      toast.success(`${vars.grant ? "Granted" : "Revoked"} ${vars.role.replaceAll("_", " ")}`);
      qc.invalidateQueries({ queryKey: ["admin-association-members", vars.association_id] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const filtered = useMemo(() => {
    const s = search.trim().toLowerCase();
    if (!s) return q.data ?? [];
    return (q.data ?? []).filter((u: any) =>
      [u.full_name, u.email, u.matric_no].some((v) => (v ?? "").toLowerCase().includes(s)),
    );
  }, [q.data, search]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold">Users &amp; roles</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Grant or revoke platform roles per user. The last Super Admin cannot be removed. Faculty / department reps still need a
          faculty or department assigned on their profile to see scoped data.
        </p>
      </div>

      <Card>
        <CardContent className="p-5 space-y-4">
          <div>
            <div className="font-display font-semibold">Association governance</div>
            <p className="text-sm text-muted-foreground mt-1">Approve association accounts and assign tenant-scoped leaders without granting platform Super Admin access.</p>
          </div>
          <div className="grid md:grid-cols-2 gap-3">
            {(associations.data ?? []).filter((a: any) => a.status === "pending").map((a: any) => (
              <div key={a.id} className="rounded-lg border p-3 flex items-center gap-3">
                <div className="flex-1 min-w-0">
                  <div className="font-medium truncate">{a.name}</div>
                  <div className="text-xs text-muted-foreground">{a.slug}</div>
                </div>
                <Button size="sm" disabled={associationApproval.isPending} onClick={() => associationApproval.mutate({ association_id: a.id, approve: true })}>Approve</Button>
                <Button size="sm" variant="outline" disabled={associationApproval.isPending} onClick={() => associationApproval.mutate({ association_id: a.id, approve: false })}>Reject</Button>
              </div>
            ))}
            {(associations.data ?? []).filter((a: any) => a.status === "pending").length === 0 && (
              <div className="text-sm text-muted-foreground">No pending association applications.</div>
            )}
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Manage scoped association roles</label>
            <select
              value={associationId}
              onChange={(e) => setAssociationId(e.target.value)}
              className="flex h-10 w-full max-w-md rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
            >
              <option value="">Select an active association</option>
              {(associations.data ?? []).filter((a: any) => a.status === "active").map((a: any) => <option key={a.id} value={a.id}>{a.name}</option>)}
            </select>
          </div>
        </CardContent>
      </Card>

      <Input
        placeholder="Search by name, email, or matric…"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="max-w-sm"
      />

      <Card>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-secondary/60 text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="text-left p-3">User</th>
                <th className="text-left p-3">Current roles</th>
                <th className="text-left p-3">Manage roles</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {filtered.map((u: any) => (
                <tr key={u.id} className="align-top">
                  <td className="p-3">
                    <div className="font-medium">{u.full_name ?? "—"}</div>
                    <div className="text-xs text-muted-foreground">{u.email}</div>
                    {u.matric_no && <div className="text-xs text-muted-foreground">{u.matric_no}</div>}
                  </td>
                  <td className="p-3">
                    <div className="flex gap-1 flex-wrap">
                      {u.roles.length === 0 && <span className="text-xs text-muted-foreground">none</span>}
                      {u.roles.map((r: string) => {
                        const meta = ROLES.find((x) => x.value === r);
                        return (
                          <Badge key={r} className={meta?.tone || ""} variant={meta?.tone ? "default" : "secondary"}>
                            {meta?.label ?? r}
                          </Badge>
                        );
                      })}
                    </div>
                  </td>
                  <td className="p-3">
                    <div className="flex gap-1.5 flex-wrap">
                      {ROLES.map((r) => {
                        const has = u.roles.includes(r.value);
                        return (
                          <Button
                            key={r.value}
                            size="sm"
                            variant={has ? "outline" : "secondary"}
                            disabled={mut.isPending}
                            onClick={() => mut.mutate({ user_id: u.id, role: r.value, grant: !has })}
                            className="h-7 text-xs"
                          >
                            {has ? <X className="h-3 w-3 mr-1" /> : <Check className="h-3 w-3 mr-1" />}
                            {has ? "Revoke" : "Grant"} {r.label}
                          </Button>
                        );
                      })}
                    </div>
                    {associationId && (
                      <div className="mt-3 pt-3 border-t">
                        <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5">Association roles</div>
                        <div className="flex gap-1.5 flex-wrap">
                          {ASSOCIATION_ROLES.map((r) => {
                            const has = (associationMembers.data ?? []).some((m: any) => m.user_id === u.id && m.role === r.value && m.status === "active");
                            return (
                              <Button
                                key={r.value}
                                size="sm"
                                variant={has ? "outline" : "secondary"}
                                disabled={associationRoleMutation.isPending}
                                onClick={() => associationRoleMutation.mutate({ association_id: associationId, user_id: u.id, role: r.value, grant: !has })}
                                className="h-7 text-xs"
                              >
                                {has ? <X className="h-3 w-3 mr-1" /> : <Check className="h-3 w-3 mr-1" />}
                                {has ? "Revoke" : "Grant"} {r.label}
                              </Button>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={3} className="p-5 text-center text-sm text-muted-foreground">No users found.</td></tr>
              )}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
