import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getEligibleRequests, getMyTransactions, getMyProfile, verifyPayment } from "@/lib/payments.functions";
import { Logo } from "@/components/brand/logo";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { formatNaira } from "@/lib/charges";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { ArrowRight, LogOut, ShieldAlert, QrCode, Receipt as ReceiptIcon } from "lucide-react";
import { getMyRoles } from "@/lib/payments.functions";
import { createAssociation, getMyAssociations, saveAssociationAccount } from "@/lib/associations.functions";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — UniEgo" }] }),
  component: Dashboard,
});

function Dashboard() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const fetchProfile = useServerFn(getMyProfile);
  const fetchEligible = useServerFn(getEligibleRequests);
  const fetchTxns = useServerFn(getMyTransactions);
  const fetchRoles = useServerFn(getMyRoles);
  const verify = useServerFn(verifyPayment);
  const createAssociationFn = useServerFn(createAssociation);
  const getMyAssociationsFn = useServerFn(getMyAssociations);
  const saveAssociationAccountFn = useServerFn(saveAssociationAccount);
  const [associationName, setAssociationName] = useState("");
  const [associationSlug, setAssociationSlug] = useState("");
  const [accountDrafts, setAccountDrafts] = useState<Record<string, { bank_name: string; account_name: string; account_number: string }>>({});

  const profile = useQuery({ queryKey: ["me"], queryFn: () => fetchProfile() });
  const roles = useQuery({ queryKey: ["my-roles"], queryFn: () => fetchRoles() });
  const eligible = useQuery({ queryKey: ["eligible"], queryFn: () => fetchEligible() });
  const associations = useQuery({ queryKey: ["my-associations"], queryFn: () => getMyAssociationsFn() });
  const txns = useQuery({ queryKey: ["my-txns"], queryFn: () => fetchTxns(), refetchInterval: (query) => {
    const rows = (query.state.data as any[] | undefined) ?? [];
    return rows.some((t) => t.status === "pending") ? 4000 : false;
  } });


  const createAssociationMutation = useMutation({
    mutationFn: () => createAssociationFn({ data: { name: associationName, slug: associationSlug } }),
    onSuccess: () => {
      toast.success("Association submitted for Super Admin approval");
      setAssociationName("");
      setAssociationSlug("");
      qc.invalidateQueries({ queryKey: ["my-associations"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const saveAccountMutation = useMutation({
    mutationFn: ({ association_id, draft }: { association_id: string; draft: { bank_name: string; account_name: string; account_number: string } }) =>
      saveAssociationAccountFn({ data: { association_id, ...draft } }),
    onSuccess: () => { toast.success("Association account updated"); qc.invalidateQueries({ queryKey: ["my-associations"] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  const verifiedRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const reference = params.get("reference") ?? params.get("trxref");
    if (!reference || verifiedRef.current.has(reference)) return;
    verifiedRef.current.add(reference);
    verify({ data: { reference } })
      .then((r) => {
        if (r.status === "paid") {
          toast.success("Payment successful");
          qc.invalidateQueries({ queryKey: ["my-txns"] });
        }
      })
      .catch(() => { /* webhook will finalize; polling picks it up */ })
      .finally(() => {
        const url = new URL(window.location.href);
        url.searchParams.delete("reference");
        url.searchParams.delete("trxref");
        window.history.replaceState({}, "", url.pathname + (url.search ? url.search : ""));
      });
  }, [verify, qc]);

  const incomplete = profile.data && (!profile.data.matric_no || !profile.data.faculty_id || !profile.data.level);
  const isAdmin = (roles.data ?? []).includes("admin");
  const isRunner = (roles.data ?? []).includes("bank_runner");
  const isRep = (roles.data ?? []).includes("faculty_rep") || (roles.data ?? []).includes("department_rep");

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="min-h-screen bg-secondary/30">
      <header className="bg-background border-b sticky top-0 z-30">
        <div className="mx-auto max-w-7xl px-6 h-16 flex items-center justify-between">
          <Link to="/"><Logo /></Link>
          <div className="flex items-center gap-2">
            {isRep && <Link to="/rep"><Button variant="outline" size="sm">Rep portal</Button></Link>}
            {isRunner && <Link to="/runner"><Button variant="outline" size="sm">Runner</Button></Link>}
            {isAdmin && <Link to="/admin"><Button variant="outline" size="sm">Super Admin</Button></Link>}
            <Button variant="ghost" size="sm" onClick={signOut}><LogOut className="h-4 w-4 mr-1.5"/>Sign out</Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-6 py-10 space-y-6">
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Welcome back</div>
          <h1 className="font-display text-3xl font-bold mt-1">{profile.data?.full_name ?? "Student"}</h1>
        </div>

        {incomplete && (
          <Card className="border-gold">
            <CardContent className="p-5 flex items-center gap-4">
              <ShieldAlert className="h-5 w-5 text-gold" />
              <div className="flex-1">
                <div className="font-medium">Complete your student profile</div>
                <div className="text-sm text-muted-foreground">Add matric number, faculty, department and level to see payment requests.</div>
              </div>
              <Link to="/onboarding"><Button size="sm">Complete</Button></Link>
            </CardContent>
          </Card>
        )}




        <section className="space-y-4">
          <div className="flex items-end justify-between gap-4 flex-wrap">
            <div>
              <h2 className="font-display text-lg font-semibold">Association access</h2>
              <p className="text-sm text-muted-foreground">Create an association account request and view association roles assigned by the Super Admin.</p>
            </div>
          </div>
          <div className="grid lg:grid-cols-2 gap-4">
            <Card>
              <CardContent className="p-5 space-y-3">
                <div className="font-medium">Create association</div>
                <Input placeholder="Association name" value={associationName} onChange={(e) => {
                  const value = e.target.value;
                  setAssociationName(value);
                  if (!associationSlug) setAssociationSlug(value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""));
                }} />
                <Input placeholder="association-slug" value={associationSlug} onChange={(e) => setAssociationSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ""))} />
                <Button
                  disabled={createAssociationMutation.isPending || associationName.trim().length < 2 || associationSlug.trim().length < 2}
                  onClick={() => createAssociationMutation.mutate()}
                >
                  {createAssociationMutation.isPending ? "Submitting…" : "Submit for approval"}
                </Button>
              </CardContent>
            </Card>

            <div className="space-y-3">
              {(associations.data ?? []).length === 0 && (
                <Card><CardContent className="p-5 text-sm text-muted-foreground">No association memberships yet.</CardContent></Card>
              )}
              {(associations.data ?? []).map((membership: any) => {
                const association = membership.association;
                const canEditAccount = membership.role === "president" || membership.role === "treasurer";
                const canViewAccount = ["president", "treasurer", "financial_secretary", "staff_adviser"].includes(membership.role);
                const current = accountDrafts[membership.association_id] ?? {
                  bank_name: membership.account?.bank_name ?? "",
                  account_name: membership.account?.account_name ?? "",
                  account_number: membership.account?.account_number ?? "",
                };
                const setDraft = (patch: Partial<typeof current>) => setAccountDrafts((prev) => ({ ...prev, [membership.association_id]: { ...current, ...patch } }));
                return (
                  <Card key={`${membership.association_id}-${membership.role}`}>
                    <CardContent className="p-5 space-y-3">
                      <div className="flex items-center justify-between gap-3">
                        <div>
                          <div className="font-medium">{association?.name ?? "Association"}</div>
                          <div className="text-xs text-muted-foreground">{association?.slug}</div>
                        </div>
                        <div className="flex gap-1.5">
                          <Badge variant="secondary">{String(membership.role).replaceAll("_", " ")}</Badge>
                          <Badge variant={association?.status === "active" ? "default" : "secondary"}>{association?.status ?? "pending"}</Badge>
                        </div>
                      </div>
                      {canViewAccount && (
                        <div className="space-y-2 border-t pt-3">
                          <div className="text-xs uppercase tracking-wider text-muted-foreground">Settlement account</div>
                          {canEditAccount ? (
                            <>
                              <Input placeholder="Bank name" value={current.bank_name} onChange={(e) => setDraft({ bank_name: e.target.value })} />
                              <Input placeholder="Account name" value={current.account_name} onChange={(e) => setDraft({ account_name: e.target.value })} />
                              <Input placeholder="Account number" inputMode="numeric" value={current.account_number} onChange={(e) => setDraft({ account_number: e.target.value.replace(/\D/g, "") })} />
                              <Button size="sm" variant="outline" disabled={saveAccountMutation.isPending} onClick={() => saveAccountMutation.mutate({ association_id: membership.association_id, draft: current })}>Save account</Button>
                            </>
                          ) : membership.account ? (
                            <div className="text-sm">
                              <div>{membership.account.bank_name ?? "—"}</div>
                              <div>{membership.account.account_name ?? "—"}</div>
                              <div className="font-mono">{membership.account.account_number ?? "—"}</div>
                            </div>
                          ) : <div className="text-sm text-muted-foreground">No settlement account has been configured.</div>}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        <section className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <h2 className="font-display text-lg font-semibold">Available payments</h2>
            {eligible.isLoading && <Card><CardContent className="p-6 text-sm text-muted-foreground">Loading…</CardContent></Card>}
            {!eligible.isLoading && (eligible.data ?? []).length === 0 && (
              <Card><CardContent className="p-6 text-sm text-muted-foreground">No payment requests match your profile yet.</CardContent></Card>
            )}
            {(eligible.data ?? []).map((r: any) => (
              <Card key={r.id} className="hover:shadow-elegant transition-shadow">
                <CardContent className="p-5 flex items-center gap-4">
                  <div className="flex-1">
                    <div className="font-display font-semibold">{r.title}</div>
                    {r.description && <div className="text-sm text-muted-foreground mt-1">{r.description}</div>}
                    <div className="mt-2 flex gap-2 flex-wrap text-xs text-muted-foreground">
                      {r.faculty?.name && <Badge variant="secondary">{r.faculty.name}</Badge>}
                      {r.department?.name && <Badge variant="secondary">{r.department.name}</Badge>}
                      {r.target_level && <Badge variant="secondary">{r.target_level}L</Badge>}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-display text-xl font-bold">{formatNaira(Number(r.base_amount))}</div>
                    <Link to="/pay/$requestId" params={{ requestId: r.id }}>
                      <Button size="sm" className="mt-2 bg-royal text-royal-foreground hover:opacity-90">
                        Pay <ArrowRight className="h-4 w-4 ml-1"/>
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="space-y-4">
            <h2 className="font-display text-lg font-semibold">Recent payments</h2>
            <Card>
              <CardContent className="p-0 divide-y">
                {(txns.data ?? []).length === 0 && <div className="p-5 text-sm text-muted-foreground">No transactions yet.</div>}
                {(txns.data ?? []).map((t: any) => (
                  <div key={t.id} className="p-4 flex items-center gap-3">
                    <div className="h-9 w-9 rounded-lg bg-secondary grid place-items-center">
                      <ReceiptIcon className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{t.payment_request?.title ?? "Payment"}</div>
                      <div className="text-xs text-muted-foreground">{t.reference}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-semibold">{formatNaira(Number(t.total_amount))}</div>
                      <div className="text-[10px] uppercase tracking-wider">
                        {t.status === "paid" ? <span className="text-emerald">Paid</span> : t.status === "pending" ? <span className="text-muted-foreground">Pending</span> : <span className="text-destructive">Failed</span>}
                      </div>
                    </div>
                    {t.status === "paid" && t.receipt?.[0]?.qr_token && (
                      <Link to="/receipt/$token" params={{ token: t.receipt[0].qr_token }}>
                        <Button size="icon" variant="ghost"><QrCode className="h-4 w-4"/></Button>
                      </Link>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
    </div>
  );
}
