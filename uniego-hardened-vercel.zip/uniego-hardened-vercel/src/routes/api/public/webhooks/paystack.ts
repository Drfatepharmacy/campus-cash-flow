import { createFileRoute } from "@tanstack/react-router";
import { createHmac, timingSafeEqual } from "node:crypto";
import { z } from "zod";
import QRCode from "qrcode";

const paystackEventSchema = z.object({
  event: z.string().min(1).max(120),
  data: z.object({
    id: z.number().int().optional(),
    reference: z.string().min(4).max(160),
    status: z.string().min(1).max(40),
    amount: z.number().int().nonnegative(),
    currency: z.string().min(3).max(8),
    paid_at: z.string().optional().nullable(),
    metadata: z.record(z.unknown()).optional(),
  }).passthrough(),
}).passthrough();

function signatureMatches(signature: string, expected: string) {
  if (!/^[a-f0-9]{128}$/i.test(signature)) return false;
  const a = Buffer.from(signature, "hex");
  const b = Buffer.from(expected, "hex");
  return a.length === b.length && timingSafeEqual(a, b);
}

export const Route = createFileRoute("/api/public/webhooks/paystack")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const secret = process.env.PAYSTACK_SECRET_KEY;
        if (!secret) return new Response("not configured", { status: 503 });

        const contentLength = Number(request.headers.get("content-length") ?? "0");
        if (contentLength > 1_000_000) return new Response("payload too large", { status: 413 });

        const signature = request.headers.get("x-paystack-signature") ?? "";
        const body = await request.text();
        if (body.length > 1_000_000) return new Response("payload too large", { status: 413 });
        const expected = createHmac("sha512", secret).update(body).digest("hex");
        if (!signatureMatches(signature, expected)) {
          return new Response("invalid signature", { status: 401 });
        }

        let parsed: unknown;
        try {
          parsed = JSON.parse(body);
        } catch {
          return new Response("invalid json", { status: 400 });
        }
        const checked = paystackEventSchema.safeParse(parsed);
        if (!checked.success) return new Response("invalid event", { status: 400 });
        const event = checked.data;

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const admin = supabaseAdmin as any;
        const eventKey = `${event.event}:${event.data.id ?? "na"}:${event.data.reference}`;
        const safePayload = {
          event: event.event,
          data: {
            id: event.data.id,
            reference: event.data.reference,
            status: event.data.status,
            amount: event.data.amount,
            currency: event.data.currency,
            paid_at: event.data.paid_at,
          },
        };

        const { error: ledgerInsertError } = await admin.from("webhook_events").insert({
          provider: "paystack",
          event_key: eventKey,
          event_type: event.event,
          reference: event.data.reference,
          payload: safePayload,
          status: "received",
        });

        if (ledgerInsertError?.code === "23505") {
          const { data: oldEvent } = await admin.from("webhook_events")
            .select("status, processed_at")
            .eq("provider", "paystack")
            .eq("event_key", eventKey)
            .maybeSingle();
          if (oldEvent?.status === "processed" && oldEvent.processed_at) {
            return new Response("already processed", { status: 200 });
          }
        } else if (ledgerInsertError) {
          return new Response("ledger unavailable", { status: 500 });
        }

        if (event.event !== "charge.success") {
          await admin.from("webhook_events").update({ status: "processed", processed_at: new Date().toISOString() })
            .eq("provider", "paystack").eq("event_key", eventKey);
          return new Response("ok", { status: 200 });
        }

        const { data: finalized, error: finalizeError } = await admin.rpc("finalize_payment", {
          p_reference: event.data.reference,
          p_gateway_id: String(event.data.id ?? ""),
          p_paid_at: event.data.paid_at ?? new Date().toISOString(),
          p_gateway_amount_kobo: event.data.amount,
          p_gateway_currency: event.data.currency.toUpperCase(),
          p_gateway_payload: safePayload.data,
          p_actor_id: null,
          p_source: "paystack_webhook",
        });

        if (finalizeError) {
          await admin.from("webhook_events").update({ status: "failed", error_code: "FINALIZATION_FAILED" })
            .eq("provider", "paystack").eq("event_key", eventKey);
          return new Response("finalization failed", { status: 500 });
        }

        if (finalized?.status === "amount_mismatch" || finalized?.status === "currency_mismatch") {
          await admin.from("webhook_events").update({
            status: "rejected",
            error_code: finalized.status,
            processed_at: new Date().toISOString(),
          }).eq("provider", "paystack").eq("event_key", eventKey);
          return new Response("gateway data mismatch", { status: 200 });
        }

        if (finalized?.status === "not_found") {
          await admin.from("webhook_events").update({ status: "rejected", error_code: "TRANSACTION_NOT_FOUND", processed_at: new Date().toISOString() })
            .eq("provider", "paystack").eq("event_key", eventKey);
          return new Response("ignored", { status: 200 });
        }

        await admin.from("webhook_events").update({ status: "processed", processed_at: new Date().toISOString() })
          .eq("provider", "paystack").eq("event_key", eventKey);

        // Email exactly once from the webhook path: only the transaction that this call finalized.
        if (finalized?.status === "paid" && finalized?.newly_finalized && finalized?.receipt_token) {
          const { data: txn } = await admin
            .from("transactions")
            .select("reference, total_amount, paid_at, student:profiles!transactions_student_id_fkey(email, full_name), payment_request:payment_requests(title)")
            .eq("reference", event.data.reference)
            .maybeSingle();

          const LOVABLE_API_KEY = process.env.LOVABLE_API_KEY;
          const RESEND_API_KEY = process.env.RESEND_API_KEY;
          const student = txn?.student;
          const paymentRequest = txn?.payment_request;
          if (LOVABLE_API_KEY && RESEND_API_KEY && student?.email) {
            const origin = new URL(request.url).origin;
            const verifyUrl = `${origin}/verify/${encodeURIComponent(finalized.receipt_token)}`;
            const receiptUrl = `${origin}/receipt/${encodeURIComponent(finalized.receipt_token)}`;
            try {
              const qrDataUrl = await QRCode.toDataURL(verifyUrl, { width: 320, margin: 1, color: { dark: "#1a1230", light: "#ffffff" } });
              const qrBase64 = qrDataUrl.split(",")[1] ?? "";
              const response = await fetch("https://connector-gateway.lovable.dev/resend/emails", {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${LOVABLE_API_KEY}`,
                  "X-Connection-Api-Key": RESEND_API_KEY,
                },
                body: JSON.stringify({
                  from: "UniEgo <onboarding@resend.dev>",
                  to: [student.email],
                  subject: `Receipt: ${paymentRequest?.title ?? "Payment"} — ${txn?.reference ?? event.data.reference}`,
                  html: `<div style="font-family:Inter,sans-serif;max-width:560px;margin:auto;padding:24px;color:#1a1230">
                    <h1 style="font-size:22px;color:#3d2169">UniEgo receipt</h1>
                    <p>Your payment for <strong>${paymentRequest?.title ?? "Payment"}</strong> was successful.</p>
                    <p><strong>Amount:</strong> ₦${Number(txn?.total_amount ?? 0).toLocaleString()}<br/>
                       <strong>Reference:</strong> ${txn?.reference ?? event.data.reference}</p>
                    <div style="text-align:center;margin:24px 0"><img src="cid:receipt-qr" alt="Verification QR" width="180" height="180"/></div>
                    <p style="text-align:center"><a href="${receiptUrl}">View receipt</a></p>
                    <p style="font-size:12px">Verify at <a href="${verifyUrl}">${verifyUrl}</a></p>
                  </div>`,
                  attachments: [{ filename: `receipt-${event.data.reference}-qr.png`, content: qrBase64, content_id: "receipt-qr", content_type: "image/png" }],
                }),
              });
              if (!response.ok) console.error("Receipt email failed", response.status);
            } catch (error) {
              console.error("Receipt email failed", error instanceof Error ? error.message : "unknown error");
            }
          }
        }

        return new Response("ok", { status: 200 });
      },
    },
  },
});
