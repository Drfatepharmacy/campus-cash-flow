import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/brand/logo";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

const searchSchema = z.object({ mode: z.enum(["signin", "signup", "forgot", "reset"]).optional() });
type AuthMode = "signin" | "signup" | "forgot" | "reset";

export const Route = createFileRoute("/auth")({
  validateSearch: searchSchema,
  head: () => ({ meta: [{ title: "Sign in — UniEgo" }, { name: "description", content: "Sign in or create your UniEgo account." }] }),
  component: AuthPage,
});

function AuthPage() {
  const { mode } = Route.useSearch();
  const navigate = useNavigate();
  const [tab, setTab] = useState<AuthMode>(mode ?? "signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setTab(mode ?? "signin");
  }, [mode]);

  useEffect(() => {
    const { data } = supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY") setTab("reset");
    });
    return () => data.subscription.unsubscribe();
  }, []);

  async function handleSignin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) return toast.error("Unable to sign in with those credentials.");
    toast.success("Welcome back");
    navigate({ to: "/dashboard" });
  }

  async function handleSignup(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { emailRedirectTo: window.location.origin, data: { full_name: fullName } },
    });
    setLoading(false);
    if (error) return toast.error("Account creation could not be completed.");
    toast.success("Account created — check your email if confirmation is required.");
    setTab("signin");
  }

  async function handleForgot(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    // Always return the same user-facing message so account existence is not disclosed.
    await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/auth?mode=reset`,
    });
    setLoading(false);
    toast.success("If an account exists for that email, a recovery link has been sent.");
  }

  async function handleReset(e: React.FormEvent) {
    e.preventDefault();
    if (password.length < 8) return toast.error("Use at least 8 characters for your new password.");
    if (password !== confirmPassword) return toast.error("Passwords do not match.");
    setLoading(true);
    const { data: sessionData } = await supabase.auth.getSession();
    if (!sessionData.session) {
      setLoading(false);
      return toast.error("This recovery link is invalid or expired. Request a new one.");
    }
    const { error } = await supabase.auth.updateUser({ password });
    if (error) {
      setLoading(false);
      return toast.error("The password could not be updated. Request a new recovery link.");
    }
    await supabase.auth.signOut();
    setLoading(false);
    setPassword("");
    setConfirmPassword("");
    toast.success("Password updated. Sign in with your new password.");
    setTab("signin");
  }

  async function handleGoogle() {
    setLoading(true);
    const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin + "/dashboard" });
    if (result.error) { setLoading(false); toast.error("Google sign-in failed"); return; }
    if (result.redirected) return;
    navigate({ to: "/dashboard" });
  }

  const showPrimaryTabs = tab === "signin" || tab === "signup";

  return (
    <div className="min-h-screen grid md:grid-cols-2">
      <aside className="hidden md:flex flex-col justify-between bg-royal text-royal-foreground p-10">
        <Link to="/"><Logo /></Link>
        <div>
          <h2 className="font-display text-4xl font-bold tracking-tight">Pay with ease.<br/>Stress free.</h2>
          <p className="mt-4 text-royal-foreground/80 max-w-md">UniEgo — premium campus payment infrastructure trusted by departments, faculties, and student organizations.</p>
        </div>
        <div className="text-xs text-royal-foreground/60">Powered by EMMTEC SECURITIES</div>
      </aside>

      <main className="flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          <div className="md:hidden mb-8"><Link to="/"><Logo /></Link></div>
          {showPrimaryTabs && (
            <div className="flex rounded-xl bg-secondary p-1 mb-6">
              <button onClick={() => setTab("signin")} className={`flex-1 rounded-lg py-2 text-sm font-medium ${tab === "signin" ? "bg-card shadow-sm" : "text-muted-foreground"}`}>Sign in</button>
              <button onClick={() => setTab("signup")} className={`flex-1 rounded-lg py-2 text-sm font-medium ${tab === "signup" ? "bg-card shadow-sm" : "text-muted-foreground"}`}>Create account</button>
            </div>
          )}

          {tab === "signin" && (
            <form onSubmit={handleSignin} className="space-y-4">
              <h1 className="font-display text-2xl font-bold">Welcome back</h1>
              <div className="space-y-2"><Label>Email</Label><Input type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
              <div className="space-y-2"><Label>Password</Label><Input type="password" required autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} /></div>
              <div className="flex justify-end">
                <button type="button" onClick={() => setTab("forgot")} className="text-xs text-royal hover:underline">Forgot password?</button>
              </div>
              <Button type="submit" disabled={loading} className="w-full bg-royal text-royal-foreground hover:opacity-90">
                {loading ? <Loader2 className="h-4 w-4 animate-spin"/> : "Sign in"}
              </Button>
            </form>
          )}

          {tab === "signup" && (
            <form onSubmit={handleSignup} className="space-y-4">
              <h1 className="font-display text-2xl font-bold">Create your account</h1>
              <div className="space-y-2"><Label>Full name</Label><Input required autoComplete="name" value={fullName} onChange={(e) => setFullName(e.target.value)} /></div>
              <div className="space-y-2"><Label>Email</Label><Input type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
              <div className="space-y-2"><Label>Password</Label><Input type="password" required minLength={8} autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} /></div>
              <Button type="submit" disabled={loading} className="w-full bg-royal text-royal-foreground hover:opacity-90">
                {loading ? <Loader2 className="h-4 w-4 animate-spin"/> : "Create account"}
              </Button>
            </form>
          )}

          {tab === "forgot" && (
            <form onSubmit={handleForgot} className="space-y-4">
              <div>
                <h1 className="font-display text-2xl font-bold">Recover your password</h1>
                <p className="text-sm text-muted-foreground mt-1">Enter your account email and we’ll send a secure recovery link.</p>
              </div>
              <div className="space-y-2"><Label>Email</Label><Input type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
              <Button type="submit" disabled={loading} className="w-full bg-royal text-royal-foreground hover:opacity-90">
                {loading ? <Loader2 className="h-4 w-4 animate-spin"/> : "Send recovery link"}
              </Button>
              <Button type="button" variant="ghost" className="w-full" onClick={() => setTab("signin")}>Back to sign in</Button>
            </form>
          )}

          {tab === "reset" && (
            <form onSubmit={handleReset} className="space-y-4">
              <div>
                <h1 className="font-display text-2xl font-bold">Choose a new password</h1>
                <p className="text-sm text-muted-foreground mt-1">Your recovery session must still be valid to complete this change.</p>
              </div>
              <div className="space-y-2"><Label>New password</Label><Input type="password" required minLength={8} autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} /></div>
              <div className="space-y-2"><Label>Confirm password</Label><Input type="password" required minLength={8} autoComplete="new-password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} /></div>
              <Button type="submit" disabled={loading} className="w-full bg-royal text-royal-foreground hover:opacity-90">
                {loading ? <Loader2 className="h-4 w-4 animate-spin"/> : "Update password"}
              </Button>
            </form>
          )}

          {showPrimaryTabs && (
            <>
              <div className="my-6 flex items-center gap-3 text-xs uppercase tracking-wider text-muted-foreground">
                <div className="h-px bg-border flex-1"/>or<div className="h-px bg-border flex-1"/>
              </div>
              <Button type="button" variant="outline" disabled={loading} onClick={handleGoogle} className="w-full">
                Continue with Google
              </Button>
            </>
          )}
        </div>
      </main>
    </div>
  );
}
