import { describe, expect, it } from "vitest";
import { calculateChargeKobo, nairaToKobo, normalizeCurrency, percentToBasisPoints } from "@/lib/payment-security";

describe("payment security helpers", () => {
  it("converts naira strings and numbers to integer kobo", () => {
    expect(nairaToKobo(5000)).toBe(500000);
    expect(nairaToKobo("1250.55")).toBe(125055);
    expect(nairaToKobo("1.005")).toBe(101);
  });

  it("calculates flat and percentage tiers in integer money", () => {
    expect(calculateChargeKobo(500000, [{ max: 5000, type: "flat", value: 250 }])).toBe(25000);
    expect(calculateChargeKobo(1000000, [{ max: null, type: "percent", value: 1.5 }])).toBe(15000);
    expect(percentToBasisPoints(1.5)).toBe(150);
  });

  it("normalizes gateway currency", () => {
    expect(normalizeCurrency("ngn")).toBe("NGN");
  });

  it("rejects invalid money", () => {
    expect(() => nairaToKobo(-1)).toThrow();
    expect(() => nairaToKobo(Number.NaN)).toThrow();
  });
});
