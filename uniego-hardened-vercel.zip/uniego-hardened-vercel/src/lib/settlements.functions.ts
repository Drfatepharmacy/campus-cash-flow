import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { requirePlatformAdmin } from "@/lib/authz";

export const listSettlements = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await requirePlatformAdmin(context as any);
    const { data, error } = await context.supabase
      .from("settlements")
      .select("*, department:departments(name)")
      .order("created_at", { ascending: false });
    if (error) throw new Error("SETTLEMENT_LIST_FAILED");
    return data ?? [];
  });

export const getUnsettledStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await requirePlatformAdmin(context as any);
    const { data, error } = await context.supabase
      .from("transactions")
      .select("base_amount, service_charge, total_amount")
      .eq("status", "paid")
      .is("settlement_id", null);
    if (error) throw new Error("SETTLEMENT_STATS_FAILED");
    const rows = data ?? [];
    return {
      count: rows.length,
      gross: rows.reduce((s: number, r: any) => s + Number(r.total_amount), 0),
      charges: rows.reduce((s: number, r: any) => s + Number(r.service_charge), 0),
      net: rows.reduce((s: number, r: any) => s + Number(r.base_amount), 0),
    };
  });

export const createSettlement = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    notes: z.string().trim().max(500).optional().nullable(),
    department_id: z.string().uuid().optional().nullable(),
    association_id: z.string().uuid().optional().nullable(),
  }).strict().parse(d))
  .handler(async ({ data, context }) => {
    await requirePlatformAdmin(context as any);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: result, error } = await (supabaseAdmin as any).rpc("create_settlement_atomic", {
      p_actor_id: context.userId,
      p_notes: data.notes ?? null,
      p_department_id: data.department_id ?? null,
      p_association_id: data.association_id ?? null,
    });
    if (error) {
      const message = String(error.message ?? "");
      if (message.includes("NO_UNSETTLED_TRANSACTIONS")) throw new Error("No unsettled paid transactions to batch.");
      if (message.includes("SETTLEMENT_CONFLICT")) throw new Error("SETTLEMENT_CONFLICT");
      throw new Error("SETTLEMENT_CREATE_FAILED");
    }
    return result as { ok: true; reference: string; count: number; amount: number };
  });

export const completeSettlement = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    id: z.string().uuid(),
    bank_reference: z.string().trim().min(2).max(120),
  }).strict().parse(d))
  .handler(async ({ data, context }) => {
    await requirePlatformAdmin(context as any);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: result, error } = await (supabaseAdmin as any).rpc("complete_settlement_atomic", {
      p_actor_id: context.userId,
      p_settlement_id: data.id,
      p_bank_reference: data.bank_reference,
    });
    if (error) throw new Error("SETTLEMENT_COMPLETE_FAILED");
    return result as { ok: true; status: string; idempotent: boolean };
  });

export const reconcileCsv = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    rows: z.array(z.object({
      reference: z.string().trim().min(3).max(160),
      amount: z.number().nonnegative().max(10_000_000),
    }).strict()).min(1).max(5000),
  }).strict().parse(d))
  .handler(async ({ data, context }) => {
    await requirePlatformAdmin(context as any);
    const refs = data.rows.map((r) => r.reference);
    const { data: txns } = await context.supabase
      .from("transactions")
      .select("reference, total_amount, status, paid_at")
      .in("reference", refs);
    const byRef = new Map((txns ?? []).map((t: any) => [t.reference, t]));
    const matched: any[] = [];
    const mismatched: any[] = [];
    const missing: any[] = [];
    for (const row of data.rows) {
      const t = byRef.get(row.reference);
      if (!t) { missing.push(row); continue; }
      if (Math.abs(Number(t.total_amount) - row.amount) > 0.01 || t.status !== "paid") {
        mismatched.push({ ...row, expected: Number(t.total_amount), status: t.status });
      } else {
        matched.push({ ...row, paid_at: t.paid_at });
      }
    }
    return { matched, mismatched, missing, total: data.rows.length };
  });

export const listUsersWithRoles = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await requirePlatformAdmin(context as any);
    const { data: profiles } = await context.supabase
      .from("profiles").select("id, email, full_name, matric_no").order("created_at", { ascending: false }).limit(200);
    const { data: roles } = await context.supabase.from("user_roles").select("user_id, role");
    const map = new Map<string, string[]>();
    for (const r of roles ?? []) {
      const arr = map.get(r.user_id) ?? [];
      arr.push(r.role);
      map.set(r.user_id, arr);
    }
    return (profiles ?? []).map((p: any) => ({ ...p, roles: map.get(p.id) ?? [] }));
  });

export const setUserRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    user_id: z.string().uuid(),
    role: z.enum(["admin", "student", "department_rep", "faculty_rep", "bank_runner"]),
    grant: z.boolean(),
  }).strict().parse(d))
  .handler(async ({ data, context }) => {
    await requirePlatformAdmin(context as any);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    if (data.grant) {
      const { error } = await supabaseAdmin.from("user_roles").insert({ user_id: data.user_id, role: data.role });
      if (error && error.code !== "23505") throw new Error("ROLE_GRANT_FAILED");
    } else {
      if (data.role === "admin") {
        const { data: admins } = await supabaseAdmin.from("user_roles").select("user_id").eq("role", "admin");
        if ((admins ?? []).length <= 1) throw new Error("Cannot remove the last Super Admin.");
      }
      const { error } = await supabaseAdmin.from("user_roles").delete().eq("user_id", data.user_id).eq("role", data.role);
      if (error) throw new Error("ROLE_REVOKE_FAILED");
    }
    await supabaseAdmin.from("audit_logs").insert({
      actor_id: context.userId,
      action: data.grant ? "platform.role_granted" : "platform.role_revoked",
      entity: "user",
      entity_id: data.user_id,
      metadata: { role: data.role },
    });
    return { ok: true };
  });
