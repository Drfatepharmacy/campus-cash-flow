import process from "node:process";

// Server-only runtime configuration. Never place secrets in VITE_* variables.
export function getServerConfig() {
  return {
    nodeEnv: process.env.NODE_ENV,
    paystackSecretKey: process.env.PAYSTACK_SECRET_KEY,
    appUrl: process.env.APP_URL,
    vercelUrl: process.env.VERCEL_URL,
  };
}

export function getAppOrigin() {
  const configured = process.env.APP_URL?.trim();
  const vercelUrl = process.env.VERCEL_URL?.trim();
  const origin = configured || (vercelUrl ? `https://${vercelUrl}` : "http://localhost:3000");
  const parsed = new URL(origin);
  if (process.env.NODE_ENV === "production" && parsed.protocol !== "https:") {
    throw new Error("APP_URL must use HTTPS in production");
  }
  return parsed.origin;
}
