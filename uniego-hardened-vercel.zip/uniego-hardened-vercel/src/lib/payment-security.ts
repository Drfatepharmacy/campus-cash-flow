function decimalToScaledInteger(value: string | number, scale: number): number {
  const raw = typeof value === "number" ? String(value) : value.trim();
  if (!/^\d+(?:\.\d+)?$/.test(raw)) throw new Error("Invalid decimal amount");
  const [whole, fraction = ""] = raw.split(".");
  const padded = (fraction + "0".repeat(scale)).slice(0, scale);
  const remainder = fraction.slice(scale);
  let result = Number(whole) * 10 ** scale + Number(padded || 0);
  if (remainder && Number(remainder[0]) >= 5) result += 1;
  if (!Number.isSafeInteger(result) || result < 0) throw new Error("Invalid decimal amount");
  return result;
}

export function nairaToKobo(amount: string | number): number {
  if (typeof amount === "number" && !Number.isFinite(amount)) throw new Error("Invalid amount");
  return decimalToScaledInteger(amount, 2);
}

export function percentToBasisPoints(percent: string | number): number {
  if (typeof percent === "number" && !Number.isFinite(percent)) throw new Error("Invalid percent");
  return decimalToScaledInteger(percent, 2);
}

export function calculateChargeKobo(
  baseKobo: number,
  tiers: Array<{ max: number | null; type: "flat" | "percent"; value: number }>,
): number {
  if (!Number.isSafeInteger(baseKobo) || baseKobo < 0) throw new Error("Invalid base amount");
  for (const tier of tiers) {
    const maxKobo = tier.max === null ? null : nairaToKobo(tier.max);
    if (maxKobo === null || baseKobo <= maxKobo) {
      if (tier.type === "flat") return nairaToKobo(tier.value);
      const bps = percentToBasisPoints(tier.value);
      const charge = Math.round((baseKobo * bps) / 10_000);
      if (!Number.isSafeInteger(charge) || charge < 0) throw new Error("Invalid service charge");
      return charge;
    }
  }
  return 0;
}

export function koboToNaira(kobo: number): number {
  if (!Number.isSafeInteger(kobo) || kobo < 0) throw new Error("Invalid kobo amount");
  return kobo / 100;
}

export function normalizeCurrency(currency: string | null | undefined): string {
  return (currency ?? "").trim().toUpperCase();
}
