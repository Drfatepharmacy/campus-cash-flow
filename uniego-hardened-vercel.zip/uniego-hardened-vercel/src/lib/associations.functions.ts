import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { requirePlatformAdmin } from "@/lib/authz";

const associationRole = z.enum(["president", "treasurer", "financial_secretary", "staff_adviser", "member"]);

export const createAssociation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    name: z.string().trim().min(2).max(160),
    slug: z.string().trim().toLowerCase().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).max(100),
    campus_id: z.string().uuid().optional().nullable(),
  }).strict().parse(d))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: allowed } = await (supabaseAdmin as any).rpc("consume_rate_limit", {
      p_bucket: "association.create", p_subject: context.userId, p_limit: 3, p_window_seconds: 3600,
    });
    if (allowed === false) throw new Error("RATE_LIMITED");
    const { data: result, error } = await (supabaseAdmin as any).rpc("create_association_application", {
      p_actor_id: context.userId,
      p_name: data.name,
      p_slug: data.slug,
      p_campus_id: data.campus_id ?? null,
    });
    if (error) {
      if (String(error.code) === "23505" || String(error.message).toLowerCase().includes("duplicate")) {
        throw new Error("ASSOCIATION_SLUG_TAKEN");
      }
      throw new Error("ASSOCIATION_CREATE_FAILED");
    }
    return result as { ok: true; id: string; status: "pending" };
  });

export const getMyAssociations = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const client = context.supabase as any;
    const { data: memberships, error } = await client
      .from("association_members")
      .select("association_id, role, status, association:associations(id,name,slug,status,campus_id)")
      .eq("user_id", context.userId)
      .eq("status", "active")
      .order("assigned_at", { ascending: true });
    if (error) throw new Error("ASSOCIATION_LIST_FAILED");

    const rows = memberships ?? [];
    const associationIds = rows.map((r: any) => r.association_id);
    let accounts: any[] = [];
    if (associationIds.length) {
      const { data } = await client
        .from("association_accounts")
        .select("association_id, bank_name, account_name, account_number, currency, updated_at")
        .in("association_id", associationIds);
      accounts = data ?? [];
    }
    const accountMap = new Map(accounts.map((a: any) => [a.association_id, a]));
    return rows.map((row: any) => ({ ...row, account: accountMap.get(row.association_id) ?? null }));
  });

export const listAssociationsAdmin = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await requirePlatformAdmin(context as any);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await (supabaseAdmin as any)
      .from("associations")
      .select("id,name,slug,status,campus_id,created_by,approved_by,approved_at,created_at")
      .order("created_at", { ascending: false });
    if (error) throw new Error("ASSOCIATION_LIST_FAILED");
    return data ?? [];
  });

export const approveAssociation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ association_id: z.string().uuid(), approve: z.boolean() }).strict().parse(d))
  .handler(async ({ data, context }) => {
    await requirePlatformAdmin(context as any);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await (supabaseAdmin as any).rpc("approve_association", {
      p_actor_id: context.userId,
      p_association_id: data.association_id,
      p_approve: data.approve,
    });
    if (error) throw new Error("ASSOCIATION_APPROVAL_FAILED");
    return { ok: true };
  });

export const setAssociationRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    association_id: z.string().uuid(),
    user_id: z.string().uuid(),
    role: associationRole,
    grant: z.boolean(),
  }).strict().parse(d))
  .handler(async ({ data, context }) => {
    await requirePlatformAdmin(context as any);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await (supabaseAdmin as any).rpc("set_association_role", {
      p_actor_id: context.userId,
      p_association_id: data.association_id,
      p_user_id: data.user_id,
      p_role: data.role,
      p_grant: data.grant,
    });
    if (error) throw new Error("ASSOCIATION_ROLE_UPDATE_FAILED");
    return { ok: true };
  });

export const listAssociationMembersAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ association_id: z.string().uuid() }).strict().parse(d))
  .handler(async ({ data, context }) => {
    await requirePlatformAdmin(context as any);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: rows, error } = await (supabaseAdmin as any)
      .from("association_members")
      .select("user_id,role,status,assigned_at")
      .eq("association_id", data.association_id);
    if (error) throw new Error("ASSOCIATION_MEMBER_LIST_FAILED");
    const userIds = [...new Set((rows ?? []).map((r: any) => r.user_id))];
    let profiles: any[] = [];
    if (userIds.length) {
      const { data: profileRows } = await (supabaseAdmin as any)
        .from("profiles")
        .select("id,full_name,email,matric_no")
        .in("id", userIds);
      profiles = profileRows ?? [];
    }
    const profileMap = new Map(profiles.map((profile: any) => [profile.id, profile]));
    return (rows ?? []).map((row: any) => ({ ...row, profile: profileMap.get(row.user_id) ?? null }));
  });

export const saveAssociationAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    association_id: z.string().uuid(),
    bank_name: z.string().trim().min(2).max(120),
    account_name: z.string().trim().min(2).max(160),
    account_number: z.string().trim().regex(/^\d{8,20}$/),
  }).strict().parse(d))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await (supabaseAdmin as any).rpc("upsert_association_account", {
      p_actor_id: context.userId,
      p_association_id: data.association_id,
      p_bank_name: data.bank_name,
      p_account_name: data.account_name,
      p_account_number: data.account_number,
    });
    if (error) {
      if (String(error.message).includes("FORBIDDEN")) throw new Error("FORBIDDEN");
      throw new Error("ASSOCIATION_ACCOUNT_UPDATE_FAILED");
    }
    return { ok: true };
  });
