export type AuthContext = {
  supabase: any;
  userId: string;
};

export async function requirePlatformAdmin(ctx: AuthContext) {
  const { data, error } = await ctx.supabase.rpc("is_platform_admin", { _user_id: ctx.userId });
  if (error) throw new Error("Authorization check failed");
  if (!data) throw new Error("FORBIDDEN");
}

export async function requireAssociationRole(
  ctx: AuthContext,
  associationId: string,
  roles: Array<"president" | "treasurer" | "financial_secretary" | "staff_adviser" | "member">,
) {
  for (const role of roles) {
    const { data, error } = await ctx.supabase.rpc("has_association_role", {
      _user_id: ctx.userId,
      _association_id: associationId,
      _role: role,
    });
    if (error) throw new Error("Authorization check failed");
    if (data) return;
  }
  throw new Error("FORBIDDEN");
}
