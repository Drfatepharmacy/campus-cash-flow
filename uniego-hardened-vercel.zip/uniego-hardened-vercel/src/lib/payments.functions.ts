import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { DEFAULT_TIERS, type Tier } from "@/lib/charges";
import { calculateChargeKobo, koboToNaira, nairaToKobo, normalizeCurrency } from "@/lib/payment-security";

const paymentRequestIdSchema = z.object({ payment_request_id: z.string().uuid() }).strict();

function assertEligible(
  pr: any,
  profile: { faculty_id?: string | null; department_id?: string | null; level?: number | null } | null,
) {
  if (!pr?.active) throw new Error("PAYMENT_NOT_ALLOWED");
  const now = Date.now();
  if (pr.opens_at && new Date(pr.opens_at).getTime() > now) throw new Error("PAYMENT_NOT_OPEN");
  if (pr.closes_at && new Date(pr.closes_at).getTime() < now) throw new Error("PAYMENT_CLOSED");
  if (pr.target_faculty_id && pr.target_faculty_id !== profile?.faculty_id) throw new Error("PAYMENT_NOT_ALLOWED");
  if (pr.target_department_id && pr.target_department_id !== profile?.department_id) throw new Error("PAYMENT_NOT_ALLOWED");
  if (pr.target_level && pr.target_level !== profile?.level) throw new Error("PAYMENT_NOT_ALLOWED");
}

async function calculateAuthoritativeAmount(supabase: any, pr: any) {
  const { data: rules, error } = await supabase.from("service_charge_rules").select("*").eq("active", true);
  if (error) throw new Error("PAYMENT_CONFIGURATION_ERROR");
  const rule = rules?.find((r: any) => r.scope === "payment_request" && r.payment_request_id === pr.id)
    ?? rules?.find((r: any) => r.scope === "department" && r.department_id === pr.target_department_id)
    ?? rules?.find((r: any) => r.scope === "global");
  const baseKobo = nairaToKobo(String(pr.base_amount));
  const tiers = (rule?.tiers as Tier[] | undefined) ?? DEFAULT_TIERS;
  const chargeKobo = calculateChargeKobo(baseKobo, tiers);
  const totalKobo = baseKobo + chargeKobo;
  return {
    base: koboToNaira(baseKobo),
    charge: koboToNaira(chargeKobo),
    total: koboToNaira(totalKobo),
    totalKobo,
  };
}

export const getMyProfile = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase.from("profiles").select("*, faculty:faculties(name), department:departments(name), campus:campuses(name)").eq("id", context.userId).maybeSingle();
    return data;
  });

export const getMyRoles = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase.from("user_roles").select("role").eq("user_id", context.userId);
    return (data ?? []).map((r) => r.role);
  });

export const updateMyProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    full_name: z.string().trim().min(2).max(120),
    phone: z.string().trim().max(20).optional().nullable(),
    matric_no: z.string().trim().regex(/^[A-Z]{3}\d{7}$/, "Matric must be 3 letters + 7 digits (e.g. PHA2006960)").optional().nullable(),
    campus_id: z.string().uuid().optional().nullable(),
    faculty_id: z.string().uuid().optional().nullable(),
    department_id: z.string().uuid().optional().nullable(),
    level: z.number().int().min(100).max(800).optional().nullable(),
  }).strict().parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("profiles").update(data).eq("id", context.userId);
    if (error) throw new Error("PROFILE_UPDATE_FAILED");
    return { ok: true };
  });

export const getEligibleRequests = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: profile } = await context.supabase.from("profiles").select("faculty_id, department_id, level").eq("id", context.userId).maybeSingle();
    const { data } = await context.supabase
      .from("payment_requests")
      .select("*, faculty:faculties(name), department:departments(name)")
      .eq("active", true)
      .order("created_at", { ascending: false });
    const now = Date.now();
    return (data ?? []).filter((r) => {
      if (r.opens_at && new Date(r.opens_at).getTime() > now) return false;
      if (r.closes_at && new Date(r.closes_at).getTime() < now) return false;
      if (r.target_faculty_id && r.target_faculty_id !== profile?.faculty_id) return false;
      if (r.target_department_id && r.target_department_id !== profile?.department_id) return false;
      if (r.target_level && r.target_level !== profile?.level) return false;
      return true;
    });
  });

export const getMyTransactions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase
      .from("transactions")
      .select("*, payment_request:payment_requests(title), receipt:receipts(id, qr_token)")
      .eq("student_id", context.userId)
      .order("created_at", { ascending: false })
      .limit(50);
    return data ?? [];
  });

export const previewCharge = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => paymentRequestIdSchema.parse(d))
  .handler(async ({ data, context }) => {
    const { data: pr } = await context.supabase.from("payment_requests").select("*").eq("id", data.payment_request_id).maybeSingle();
    const { data: profile } = await context.supabase.from("profiles").select("faculty_id, department_id, level").eq("id", context.userId).maybeSingle();
    if (!pr) throw new Error("PAYMENT_REQUEST_NOT_FOUND");
    assertEligible(pr, profile);
    const amount = await calculateAuthoritativeAmount(context.supabase, pr);
    return { title: pr.title, base_amount: amount.base, service_charge: amount.charge, total_amount: amount.total };
  });

export const initiatePayment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    payment_request_id: z.string().uuid(),
    idempotency_key: z.string().uuid(),
  }).strict().parse(d))
  .handler(async ({ data, context }) => {
    const { getServerConfig, getAppOrigin } = await import("@/lib/config.server");
    const { paystackSecretKey } = getServerConfig();
    if (!paystackSecretKey) throw new Error("PAYMENTS_NOT_CONFIGURED");

    const [{ data: pr }, { data: profile }] = await Promise.all([
      context.supabase.from("payment_requests").select("*").eq("id", data.payment_request_id).maybeSingle(),
      context.supabase.from("profiles").select("email, full_name, faculty_id, department_id, level").eq("id", context.userId).maybeSingle(),
    ]);
    if (!pr) throw new Error("PAYMENT_REQUEST_NOT_FOUND");
    if (!profile?.email) throw new Error("PROFILE_INCOMPLETE");
    assertEligible(pr, profile);

    const { base, charge, total, totalKobo: amountKobo } = await calculateAuthoritativeAmount(context.supabase, pr);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const admin = supabaseAdmin as any;
    const { data: allowed } = await admin.rpc("consume_rate_limit", {
      p_bucket: "payment.initialize", p_subject: context.userId, p_limit: 8, p_window_seconds: 60,
    });
    if (allowed === false) throw new Error("RATE_LIMITED");

    const { data: existing } = await admin
      .from("transactions")
      .select("id, reference, status, authorization_url")
      .eq("student_id", context.userId)
      .eq("payment_request_id", pr.id)
      .eq("idempotency_key", data.idempotency_key)
      .maybeSingle();

    if (existing?.authorization_url && existing.status === "pending") {
      return { authorization_url: existing.authorization_url as string, reference: existing.reference as string };
    }
    if (existing?.status === "paid") throw new Error("PAYMENT_ALREADY_PROCESSED");

    let reference = existing?.reference ?? `UEG-${crypto.randomUUID().replaceAll("-", "").toUpperCase()}`;
    let transactionId = existing?.id as string | undefined;

    if (!transactionId) {
      const { data: inserted, error: insertError } = await admin
        .from("transactions")
        .insert({
          reference,
          student_id: context.userId,
          payment_request_id: pr.id,
          base_amount: base,
          service_charge: charge,
          total_amount: total,
          currency: "NGN",
          idempotency_key: data.idempotency_key,
          status: "pending",
        })
        .select("id")
        .single();

      if (insertError) {
        if (insertError.code !== "23505") throw new Error("PAYMENT_INITIALIZATION_FAILED");
        const { data: raced } = await admin
          .from("transactions")
          .select("id, reference, status, authorization_url")
          .eq("student_id", context.userId)
          .eq("payment_request_id", pr.id)
          .eq("idempotency_key", data.idempotency_key)
          .single();
        if (raced.authorization_url && raced.status === "pending") {
          return { authorization_url: raced.authorization_url as string, reference: raced.reference as string };
        }
        transactionId = raced.id;
        reference = raced.reference;
      } else {
        transactionId = inserted.id;
      }
    }

    if (!transactionId) throw new Error("PAYMENT_INITIALIZATION_FAILED");

    // Only one concurrent request may initialize a gateway session for this transaction.
    const initializationToken = crypto.randomUUID();
    const staleBefore = new Date(Date.now() - 2 * 60_000).toISOString();
    const { data: claimed } = await admin
      .from("transactions")
      .update({ initialization_token: initializationToken, initialization_claimed_at: new Date().toISOString() })
      .eq("id", transactionId)
      .is("authorization_url", null)
      .or(`initialization_token.is.null,initialization_claimed_at.lt.${staleBefore}`)
      .select("id")
      .maybeSingle();

    if (!claimed) {
      const { data: current } = await admin.from("transactions")
        .select("authorization_url,reference,status")
        .eq("id", transactionId)
        .maybeSingle();
      if (current?.authorization_url && current.status === "pending") {
        return { authorization_url: current.authorization_url as string, reference: current.reference as string };
      }
      throw new Error("PAYMENT_INITIALIZATION_IN_PROGRESS");
    }

    const callbackUrl = new URL("/dashboard", getAppOrigin()).toString();
    let response: Response;
    try {
      response = await fetch("https://api.paystack.co/transaction/initialize", {
        method: "POST",
        headers: { Authorization: `Bearer ${paystackSecretKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          email: profile.email,
          amount: amountKobo,
          currency: "NGN",
          reference,
          callback_url: callbackUrl,
          metadata: { payment_request_id: pr.id, student_id: context.userId, transaction_id: transactionId },
        }),
      });
    } catch {
      await admin.from("transactions").update({ initialization_token: null, initialization_claimed_at: null })
        .eq("id", transactionId).eq("initialization_token", initializationToken);
      throw new Error("PAYSTACK_INITIALIZATION_FAILED");
    }

    const json = await response.json() as {
      status?: boolean;
      message?: string;
      data?: { authorization_url?: string; access_code?: string; reference?: string };
    };
    if (!response.ok || !json.status || !json.data?.authorization_url) {
      await admin.from("transactions").update({ initialization_token: null, initialization_claimed_at: null })
        .eq("id", transactionId).eq("initialization_token", initializationToken);
      throw new Error("PAYSTACK_INITIALIZATION_FAILED");
    }
    if (json.data.reference && json.data.reference !== reference) {
      await admin.from("transactions").update({ initialization_token: null, initialization_claimed_at: null })
        .eq("id", transactionId).eq("initialization_token", initializationToken);
      throw new Error("PAYSTACK_REFERENCE_MISMATCH");
    }

    const { data: saved } = await admin.from("transactions").update({
      authorization_url: json.data.authorization_url,
      access_code: json.data.access_code ?? null,
      initialization_token: null,
      initialization_claimed_at: null,
    }).eq("id", transactionId).eq("initialization_token", initializationToken).select("id").maybeSingle();
    if (!saved) throw new Error("PAYMENT_INITIALIZATION_CONFLICT");

    return { authorization_url: json.data.authorization_url, reference };
  });

export const verifyPayment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ reference: z.string().trim().min(8).max(120) }).strict().parse(d))
  .handler(async ({ data, context }) => {
    const { getServerConfig } = await import("@/lib/config.server");
    const { paystackSecretKey } = getServerConfig();
    if (!paystackSecretKey) throw new Error("PAYMENTS_NOT_CONFIGURED");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: allowed } = await (supabaseAdmin as any).rpc("consume_rate_limit", {
      p_bucket: "payment.verify", p_subject: context.userId, p_limit: 20, p_window_seconds: 60,
    });
    if (allowed === false) throw new Error("RATE_LIMITED");

    const { data: txn } = await context.supabase
      .from("transactions")
      .select("id, status, student_id")
      .eq("reference", data.reference)
      .maybeSingle();
    if (!txn) throw new Error("TRANSACTION_NOT_FOUND");
    if (txn.student_id !== context.userId) throw new Error("FORBIDDEN");
    if (txn.status === "paid") return { status: "paid" as const };

    const response = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(data.reference)}`, {
      headers: { Authorization: `Bearer ${paystackSecretKey}` },
    });
    const json = await response.json() as {
      status?: boolean;
      data?: {
        status?: string;
        reference?: string;
        amount?: number;
        currency?: string;
        paid_at?: string;
        id?: number;
      };
    };
    if (!response.ok || !json.status || !json.data) throw new Error("PAYMENT_VERIFICATION_FAILED");
    if (json.data.reference !== data.reference) throw new Error("PAYSTACK_REFERENCE_MISMATCH");
    if (json.data.status !== "success") return { status: "pending" as const };

    const { data: result, error } = await (supabaseAdmin as any).rpc("finalize_payment", {
      p_reference: data.reference,
      p_gateway_id: String(json.data.id ?? ""),
      p_paid_at: json.data.paid_at ?? new Date().toISOString(),
      p_gateway_amount_kobo: Number(json.data.amount ?? -1),
      p_gateway_currency: normalizeCurrency(json.data.currency),
      p_gateway_payload: {
        status: json.data.status,
        reference: json.data.reference,
        amount: json.data.amount,
        currency: json.data.currency,
        paid_at: json.data.paid_at,
        id: json.data.id,
      },
      p_actor_id: context.userId,
      p_source: "manual_verification",
    });
    if (error) throw new Error("PAYMENT_FINALIZATION_FAILED");

    if (result?.status === "paid") return { status: "paid" as const };
    if (result?.status === "amount_mismatch") throw new Error("PAYMENT_AMOUNT_MISMATCH");
    if (result?.status === "currency_mismatch") throw new Error("PAYMENT_CURRENCY_MISMATCH");
    return { status: "pending" as const };
  });
